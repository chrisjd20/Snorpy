#!/usr/bin/env python3
#Under Construction, Snorpy.com
#Created by Christopher Davis
from flask import Flask, request, redirect, url_for, send_from_directory
import flask
from flask import Flask, request, current_app
import re
from datetime import datetime
import logging
import logging.handlers
import codecs
app = Flask(__name__)
app.debug = False

index = open('index.html','r')
index = index.read()

def digitCheck(digit):
    return bool(re.search(r"^(\d{1,10})$", digit))

def headerCheck(option):
    return bool(re.search(r'^(any|alert|drop|pass|activate|dynamic|drop|reject|sdrop|tcp|icmp|udp|ip|\$\w+_*\w*|(?:(?:(?:1\d\d|2[0-4]\d|25[0-5]|\d\d|\d)\.){3}(?:1\d\d|2[0-4]\d|25[0-5]|\d\d|\d)(?:/[1-3][0-9])*/{0,1}[1-3]{0,1})[0-9]{0,1}|[\>\<\=]|GET|POST|HEAD|OPTIONS|DELETE|CONNECT|PUT|TRACE|100|101|200|201|202|203|204|205|206|300|301|302|303|304|305|306|307|400|401|402|403|404|405|406|407|408|409|410|411|412|413|415|416|417|500|501|502|503|504|505|ACK|SYN|PSH|RST|FIN|URG|\+|\*|FROM_SERVER|FROM_CLIENT|TO_SERVER|TO_CLIENT|established|stateless|not_established|URL|CVE|BUG|MSB|NESS|ARAC|OSVD|MCAF|limit|threshold|both|by_src|by_dst|\[(?:\!*\[(?:.+?)\])*(?:.+?)*(?:\!*\[(?:.+?)\])*(?:.+?)*(?:\!*\[(?:.+?)\])*\]|\#)$',option))

def portChecker(port):
    if bool(re.search(r'^(any|\$\w+_*\w*)$',port)):
        return True
    try:
        if ':' in port:
            pRange = port.split(':')
            if len(pRange) != 2:
                return False
            else:
                if int(pRange[0]) < 1 or int(pRange[0]) > 65535 or int(pRange[1]) < 1 or int(pRange[1]) > 65535:
                    return False
                elif int(pRange[0]) > int(pRange[1]):
                    return False
                else:
                    return True
        else:
            if int(port) < 1 or int(port) > 65535:
                return False
            elif int(port) > 0 and int(port) < 65535:
                return True
    except:
        return False

def convertContent(content):
    string = '\`  \~  \!  \@  \#  \$  \%  \^  \&  \*  \)  \(  \-  \_  \=  \+  \]  \[  \}  \{  \\  \;  \:  \'  \"  \,  \<  \.  \>  \/  \? '
    indicate = 0
    tmpcontent = ''
    for i in content:
        if i in string:
            indicate += 1
            break
        else:
            continue
    if indicate == 0:
        return content
    else:
        for i in content:
            if i in string:
                tmpcontent += '|' + codecs.encode(i.encode(),'hex_codec').decode('utf-8')+ '|'
            else:
                tmpcontent += i
    tmpcontent = re.sub(r'\|\|', " ", tmpcontent)
    return tmpcontent

@app.route('/index.html')
@app.route('/')
def hello_world():
    app.logger.error(str(datetime.now())+' | '+request.remote_addr+ ' | '+ request.method+ ' | '+ request.url + ' | '+request.headers.get('User-Agent'))
    return index

@app.route('/index.py', methods=['GET', 'POST'])
def submit():
    if request.method == 'POST':
        tmpindex = index
        if request.form['ttlevaluator'] == '#' and request.form["ttl"] != '' and headerCheck(request.form["ttlevaluator"]) and digitCheck(request.form["ttl"]):
            ttl = " ttl:" + request.form["ttl"] + ';'
        elif request.form["ttlevaluator"] != '' and request.form["ttl"] != '' and headerCheck(request.form["ttlevaluator"]) and digitCheck(request.form["ttl"]):
            ttl = " ttl:"+ request.form["ttlevaluator"] + request.form["ttl"] + ';'
        else:
            ttl = ''
            
        if request.form['icmptypeevaluator'] == '#' and request.form["icmptype"] != '' and headerCheck(request.form["icmptypeevaluator"]) and digitCheck(request.form["icmptype"]):
            itype = " itype:" + request.form["icmptype"] + ';'
        elif request.form["icmptypeevaluator"] != '' and request.form["icmptype"] != '' and headerCheck(request.form["icmptypeevaluator"]) and digitCheck(request.form["icmptype"]):
            itype = " itype:"+ request.form["icmptypeevaluator"] + request.form["icmptype"] + ';'
        else:
            itype = ''

        if request.form['icmpcodeevaluator'] == '#' and request.form["icmpcode"] != '' and headerCheck(request.form["icmpcodeevaluator"]) and digitCheck(request.form["icmpcode"]):
            icode = " icode:" + request.form["icmpcode"] + ';'
        elif request.form["icmpcodeevaluator"] != '' and request.form["icmpcode"] != '' and headerCheck(request.form["icmpcodeevaluator"]) and digitCheck(request.form["icmpcode"]):
            icode = " icode:"+ request.form["icmpcodeevaluator"] + request.form["icmpcode"] + ';'
        else:
            icode = ''
        
        if request.form["ipprotoevaluator"] == '#' and request.form["ipprotofield"] != '' and headerCheck(request.form["ipprotoevaluator"]) and digitCheck(request.form["ipprotofield"]):
            ip_proto = " ip_proto:"+ request.form["ipprotofield"] + ';'
        elif request.form["ipprotoevaluator"] != '' and request.form["ipprotofield"] != '' and headerCheck(request.form["ipprotoevaluator"]) and digitCheck(request.form["ipprotofield"]):
            ip_proto = " ip_proto:"+ request.form["ipprotoevaluator"] + request.form["ipprotofield"] + ';'
        else:
            ip_proto = ''
        if request.form["httpmethodForm"] != '' and headerCheck(request.form["httpmethodForm"]):
            http_method = " content:\""+ request.form["httpmethodForm"]+ '\"; http_method;'
        else:
            http_method = ''
        if request.form["httpstatuscode"] != '' and headerCheck(request.form["httpstatuscode"]):
            http_status_code = " content:\""+ request.form["httpstatuscode"]+ '\"; http_stat_code;'
        else:
            http_status_code = ''
        if request.form['ACK'] != '' or request.form['SYN'] != '' or request.form['PSH'] != '' or request.form['RST'] != '' or request.form['FIN'] != '' or request.form['URG'] != '' or request.form['+'] != '' or request.form['*'] != '' :
            flags = ' flags:'
            flagList = ['*',"+",'ACK','SYN','PSH','RST','FIN','URG']
            for i in flagList:
                if request.form[i] != '' and headerCheck(request.form[i]):
                    flags += (request.form[i])[:1]
            if '*+' in flags:
                flags = flags.replace('+','')
            elif flags == ' flags:':
                flags = ''
        else:
            flags = ''
        tcpflow = ''
        if request.form["tcpdirectionForm"] != '' and headerCheck(request.form["tcpdirectionForm"]):
            tcpflow = ' flow:'+ (request.form["tcpdirectionForm"]).lower() + ';'
        if request.form["tcpstateForm"] != '' and request.form["tcpdirectionForm"] != '' and headerCheck(request.form["tcpstateForm"]) and headerCheck(request.form["tcpdirectionForm"]):
            tcpflow = tcpflow[:-1] + ',' + request.form["tcpstateForm"] +';'
        if request.form["udpdirectionForm"] != '' and headerCheck(request.form["udpdirectionForm"]):
            tcpflow = ' flow:'+ (request.form["udpdirectionForm"]).lower() + ';'
        if request.form["datasizeEval"] != '' and request.form["datasize"] != '' and headerCheck(request.form["datasizeEval"]) and digitCheck(request.form["datasize"]):
            dsize = " dsize:"+ request.form["datasize"] + ';'
        elif request.form["datasizeEval"] != '' and request.form["datasize"] != '' and headerCheck(request.form["datasizeEval"]) and digitCheck(request.form["datasize"]):
            dsize = " dsize:"+ request.form["datasizeEval"] + request.form["datasize"] + ';'
        else:
            dsize = ''
        if request.form["reftype"] != '' and request.form["referencetext"] != '' and headerCheck(request.form["reftype"]):
            ref = " reference:"+ request.form["reftype"].lower() +','+ request.form["referencetext"] + ';'
        else:
            ref = ''

        if request.form["content1"] != '':
            content1 = " content:"+'"'+convertContent(request.form["content1"])+'";'
        else:
            content1 = ''
        if request.form['content1not'] != '' and content1 != '':
            content1 = content1[:9]+'!'+ content1[9:]
        if request.form["content1offset"] != '' and content1 != '':
            content1 += ' offset:'+ request.form["content1offset"] + ';'
        if request.form["content1depth"] != '' and content1 != '':
            content1 += ' depth:'+ request.form["content1depth"] + ';'
        if request.form['content1nocase'] != '' and content1 != '':
            content1 += ' ' + request.form['content1nocase']+';'
        if request.form["content1uri"] != '' and content1 != '':
            content1 += ' '+request.form["content1uri"]+';'
        
        if request.form["content2"] != '':
            content2 = " content:"+'"'+convertContent(request.form["content2"])+'";'
        else:
            content2 = ''
        if request.form['content2not'] != '' and content2 != '':
            content2 = content2[:9]+'!'+ content2[9:]
        if request.form["content2offset"] != '' and content2 != '':
            content2 += ' offset:'+ request.form["content2offset"] + ';'
        if request.form["content2depth"] != '' and content2 != '':
            content2 += ' depth:'+ request.form["content2depth"] + ';'
        if request.form['content2nocase'] != '' and content2 != '':
            content2 += ' ' + request.form['content2nocase']+';'
        if request.form["content2uri"] != '' and content2 != '':
            content2 += ' '+request.form["content2uri"]+';'

        if request.form['pcre1'] != '':
            pcre1 = ' pcre:"/'+ request.form['pcre1'] + '/";'
        else:
            pcre1 = ''
        if request.form['pcre1nocase'] == 'pcre1nocase' and request.form['pcre1'] != '':
            pcre1 = pcre1[:-2] + 'i";'
        if request.form['pcre1dotall'] == 'pcre1dotall' and request.form['pcre1'] != '':
            pcre1 = pcre1[:-2] + 's";'
        if request.form['pcre1newline'] == 'pcre1newline' and request.form['pcre1'] != '':
            pcre1 = pcre1[:-2] + 'm";'
        if request.form['pcre1whitespace'] == 'pcre1whitespace' and request.form['pcre1'] != '':
            pcre1 = pcre1[:-2] + 'x";'
        if request.form['pcre1greedy'] == 'pcre1greedy' and request.form['pcre1'] != '':
            pcre1 = pcre1[:-2] + 'G";'

        if request.form['pcre2'] != '':
            pcre2 = ' pcre:"/'+ request.form['pcre2'] + '/";'
        else:
            pcre2 = ''
        if request.form['pcre2nocase'] == 'pcre2nocase' and request.form['pcre2'] != '':
            pcre2 = pcre2[:-2] + 'i";'
        if request.form['pcre2dotall'] == 'pcre2dotall' and request.form['pcre2'] != '':
            pcre2 = pcre2[:-2] + 's";'
        if request.form['pcre2newline'] == 'pcre2newline' and request.form['pcre2'] != '':
            pcre2 = pcre2[:-2] + 'm";'
        if request.form['pcre2whitespace'] == 'pcre2whitespace' and request.form['pcre2'] != '':
            pcre2 = pcre2[:-2] + 'x";'
        if request.form['pcre2greedy'] == 'pcre2greedy' and request.form['pcre2'] != '':
            pcre2 = pcre2[:-2] + 'G";'

        if request.form['sid'] != '' and digitCheck(request.form['sid']):
            sid = ' sid:'+ request.form['sid']+ ';'
        else:
            sid = ''
        if request.form['rev'] != '' and digitCheck(request.form['rev']):
            rev = ' rev:'+request.form['rev']+ ';'
        else:
            rev = ' rev:1;'
        if request.form['classtype'] != '':
            classtype = ' classtype:'+ request.form['classtype'] + ';'
        else:
            classtype = ''
        if request.form['priority'] != '' and digitCheck(request.form['priority']):
            priority = ' priority:'+ request.form['priority'] + ';'
        else:
            priority = ''
        if request.form['gid'] != '' and digitCheck(request.form['gid']):
            gid = ' gid:'+ request.form['gid'] + ';'
        else:
            gid = ''

        if request.form['thresholdtype'] != '' and request.form['trackby'] != '' and request.form['count'] != '' and request.form['seconds'] != '' and headerCheck(request.form['thresholdtype']) and headerCheck(request.form['trackby']) and headerCheck(request.form['count']) and headerCheck('seconds'):
            threshold = ' threshold:'+ request.form['thresholdtype']+' , track '+request.form['trackby']+ ' , count '+request.form['count']+ ' , seconds '+request.form['seconds']+' ;'
        else:
            threshold = ''

        if headerCheck(request.form['action']) and headerCheck(request.form['Protocol']) and headerCheck(request.form['srcnetwork']) and portChecker(request.form['srcport']) and headerCheck(request.form['dstnetwork']) and portChecker(request.form['dstport']):
            rulestring = ('Rule will display here upon submit.">'+request.form["action"] + " " + request.form["Protocol"] + " " + request.form["srcnetwork"] + " " +request.form["srcport"] + " -> " + request.form["dstnetwork"] + " " +
                    request.form["dstport"] + " (msg:\""+request.form["msg"]+'\";' + http_method + http_status_code + content1 + content2 + pcre1 + pcre2 + flags + tcpflow + dsize + ttl + ip_proto +itype+icode+ ref + threshold +classtype + priority + gid + sid + rev + ')' + '</textarea>')
            tmpindex = re.sub(r'Rule\swill\sdisplay\shere\supon\ssubmit\.\"\>.*?\<\/textarea\>', rulestring, tmpindex)
            app.logger.error(str(datetime.now())+' | '+request.remote_addr+ ' | '+ request.method+ ' | '+ request.url + ' | '+request.headers.get('User-Agent'))
            return tmpindex
        else:
            rulestring = ('Rule will display here upon submit.">'+'You input an incorrect value in the action, protocol, source network, source port, destination network or destination port. It\'s the most important part of the rule! Try again.'+ '</textarea>')
            tmpindex = re.sub(r'Rule\swill\sdisplay\shere\supon\ssubmit\.\"\>.*?\<\/textarea\>', rulestring, tmpindex)
            return tmpindex

    else:
        app.logger.error(str(datetime.now())+' | '+request.remote_addr+ ' | '+ request.method+ ' | '+ request.url + ' | '+request.headers.get('User-Agent'))
        return index

if __name__ == '__main__':
    handler = logging.handlers.RotatingFileHandler('snorpy.log', maxBytes=100000, backupCount=2)
    handler.setLevel(logging.WARNING)
    app.logger.addHandler(handler)
    app.run(host='0.0.0.0',port=80)

