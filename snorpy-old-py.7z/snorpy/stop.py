#!/usr/bin/env python3
import subprocess
import re

process = subprocess.Popen("ps aux | grep snorpy.py", stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)
processOut, processErr = process.communicate()
process = re.search(r"root\W+?(\d{3,5}).+?python3.+?snorpy.py", processOut.decode('utf-8'))
tmpprocess = process.group(1)
subprocess.call("kill " + tmpprocess, shell=True)
print('ServerStopped')
