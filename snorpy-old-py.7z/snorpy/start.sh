#!/bin/bash
cd /home/chrislab/snorpy
nohup /usr/bin/env python3 /home/chrislab/snorpy/snorpy.py > /dev/null &
echo Snorpy.com Started!
